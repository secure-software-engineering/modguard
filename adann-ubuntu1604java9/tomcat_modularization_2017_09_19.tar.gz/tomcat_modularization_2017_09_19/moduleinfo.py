import sys
import os
import shutil



def moduleinf():
    cwd = os.getcwd()
    for root, dirs, files in os.walk(cwd):
      #  print(root)
        print(dirs)
        for dir in dirs:
            with open(os.path.join(cwd,dir,"module-info.java"),"w+") as file:
               file.write('module {0} {{ }}'.format(dir))
               print(dir)
       # print(files)
       ## only top level dir
        break


def renameFolder():
    cwd = os.getcwd()
    for root, dirs, files in os.walk(cwd):
      #  print(root)
        print(dirs)
        for dir in dirs:
            os.rename(dir, dir.replace("-", "."))
            print(dir)
       # print(files)
       ## only top level dir
        break

if  __name__ =='__main__':
    renameFolder()
