module annotations.api {
    exports javax.annotation;
    exports javax.annotation.security;
    exports javax.annotation.sql;
    exports javax.ejb;
    exports javax.persistence;
    exports javax.xml.ws;
}
