module tomcat.dbcp {
    requires transitive java.logging;
    requires transitive java.management;
    requires transitive java.naming;
    requires transitive java.sql;
    requires transitive tomcat.juli;
    exports org.apache.tomcat.dbcp.dbcp2;
    exports org.apache.tomcat.dbcp.dbcp2.cpdsadapter;
    exports org.apache.tomcat.dbcp.dbcp2.datasources;
    exports org.apache.tomcat.dbcp.pool2;
    exports org.apache.tomcat.dbcp.pool2.impl;
}
