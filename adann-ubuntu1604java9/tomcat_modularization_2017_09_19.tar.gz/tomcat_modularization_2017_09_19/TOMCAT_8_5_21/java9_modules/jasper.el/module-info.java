module jasper.el {
    requires transitive el.api;
    requires transitive java.desktop;
    exports org.apache.el;
    exports org.apache.el.lang;
    exports org.apache.el.parser;
    exports org.apache.el.stream;
    exports org.apache.el.util;
}
