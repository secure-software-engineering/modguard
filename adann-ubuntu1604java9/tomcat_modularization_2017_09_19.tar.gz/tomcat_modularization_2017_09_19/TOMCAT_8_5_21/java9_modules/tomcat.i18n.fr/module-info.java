module tomcat.i18n.fr {
}
