module jasper {
    requires transitive ant;
    requires ecj;
    requires transitive el.api;
    requires transitive java.desktop;
    requires transitive java.xml;
    requires transitive jsp.api;
    requires transitive servlet.api;
    requires transitive tomcat.api;
    requires tomcat.juli;
    requires tomcat.util;
    requires transitive tomcat.util.scan;
    exports org.apache.jasper;
    exports org.apache.jasper.compiler;
    exports org.apache.jasper.compiler.tagplugin;
    exports org.apache.jasper.el;
    exports org.apache.jasper.runtime;
    exports org.apache.jasper.security;
    exports org.apache.jasper.servlet;
    exports org.apache.jasper.tagplugins.jstl;
    exports org.apache.jasper.tagplugins.jstl.core;
    exports org.apache.jasper.util;
    exports org.apache.jasper.xmlparser;
    provides javax.servlet.ServletContainerInitializer with
        org.apache.jasper.servlet.JasperInitializer;
}
