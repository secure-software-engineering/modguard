module tomcat.jdbc {
    requires transitive java.logging;
    requires transitive java.management;
    requires transitive java.naming;
    requires transitive java.sql;
    requires tomcat.juli;
    exports org.apache.tomcat.jdbc.naming;
    exports org.apache.tomcat.jdbc.pool;
    exports org.apache.tomcat.jdbc.pool.interceptor;
    exports org.apache.tomcat.jdbc.pool.jmx;
}
