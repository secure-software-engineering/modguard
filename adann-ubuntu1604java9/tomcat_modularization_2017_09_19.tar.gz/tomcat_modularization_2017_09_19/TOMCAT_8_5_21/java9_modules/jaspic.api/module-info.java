module jaspic.api {
    exports javax.security.auth.message;
    exports javax.security.auth.message.callback;
    exports javax.security.auth.message.config;
    exports javax.security.auth.message.module;
}
