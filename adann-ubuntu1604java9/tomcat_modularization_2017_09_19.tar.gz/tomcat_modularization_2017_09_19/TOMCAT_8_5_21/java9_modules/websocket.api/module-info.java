module websocket.api {
    exports javax.websocket;
    exports javax.websocket.server;
}
