import sys
import os
import shutil
import subprocess


def moduleinf():
    cwd = os.getcwd()
    return_code = subprocess.call("cd .. && ant -f buildj9_minExp.xml compile", shell=True) 
    if return_code != 0:
      print("Does not compile OUT-OF-THE BOX!!!!!!!!")
      sys.exit(1)    

    for root, dirs, files in os.walk(cwd):
      #  print(root)
        print(dirs)
        for dir in dirs:
            
            filename = os.path.join(cwd,dir,"module-info.java")
            with open(filename,"r") as file:
               print(dir)
               print(filename)
               fileContent = []
               exportIndicies= []
               ## collect the lines containing export entries
               for counter, line in enumerate(file):
                fileContent.append(line)
                print(line)
                ## special case for services
                if "exports" in line and not ("javax.servlet" in line):
                    exportIndicies.append(counter)
               print(exportIndicies)
               if exportIndicies:
                print(fileContent[exportIndicies[0]])

               return_code = subprocess.call("cd .. && ant -f buildj9_minExp.xml clean", shell=True)      
               return_code = subprocess.call("cd .. && ant -f buildj9_minExp.xml compile", shell=True) 
               if return_code != 0:
                print("Does not compile for {}!!!!!!!!".format(filename))  
                sys.exit(-1)

               ## now, open the file and try to remove as much exports as possible
               canBeRemoved = []
               for i, index in enumerate(exportIndicies):
                print("Working on file {}".format(filename))
                canBeRemoved.append(index)
                print("Remove Index: {}".format(index))
                outputToWrite = [element for i, element in enumerate(fileContent) if i not in canBeRemoved]
                f = open(filename, 'w')
                f.writelines(outputToWrite)
                f.close()  
                return_code = subprocess.call("cd .. && ant -f buildj9_minExp.xml clean", shell=True)      
                return_code = subprocess.call("cd .. && ant -f buildj9_minExp.xml compile", shell=True)      
                if return_code != 0:
                    print("Failure")
                    canBeRemoved.remove(index)
                    ## we are in the last iteration, and the build failed, thus re-add the previous removed line
                    if i == len(exportIndicies) - 1:
                      outputToWrite = [element for i, element in enumerate(fileContent) if i not in canBeRemoved]
                      f = open(filename, 'w')
                      f.writelines(outputToWrite)
                      f.close()  
                else:
                    print("Success")  
       # print(files)
       ## only top level dir
        break


def renameFolder():
    cwd = os.getcwd()
    for root, dirs, files in os.walk(cwd):
      #  print(root)
        print(dirs)
        for dir in dirs:
            os.rename(dir, dir.replace("-", "."))
            print(dir)
       # print(files)
       ## only top level dir
        break

if  __name__ =='__main__':
    moduleinf()